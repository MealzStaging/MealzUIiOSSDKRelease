# 1.1.0
[FEA] Building blocks of Product views now shared & easily accessed
[FEA] Add Dynamic Toolbar for Catalog & Catalog Results

# 1.0.0
- Initial Release


