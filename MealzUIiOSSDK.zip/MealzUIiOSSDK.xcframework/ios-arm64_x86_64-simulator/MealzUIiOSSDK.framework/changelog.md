# 1.1.0
[FEA] Building blocks of Product views now shared & easily accessed

# 1.0.0
- Initial Release


