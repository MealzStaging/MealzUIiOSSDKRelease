# MealzUIiOSSDK
Miam repo for our Neutral components. This will be provided as both a way to see how our components work as well as a forkable repository to customize for our clients.

To build the XCFramework for this project, just set your ENV variables:

`export MEALZ_PROJECT_DIR="/path/to/your/project"`

`export DERIVED_DATA_DIR="/path/to/your/xcode/devrived/data"`

And then run the script:

`sh build_xcframework.sh`

This will create a XCFramework in the /build folder that you can then export (like release with MealzUIiOSSDKRelease).
# MealzUIiOSSDK
